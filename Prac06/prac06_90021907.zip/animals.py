#
# animals.py 
#
class dog():
	myclass = "dog"

	def __init__(self, name, dob, colour, breed):
		self.name = name
		self.dob = dob
		self.colour = colour
		self.breed = breed

	def printit(self):
		print('Name: ', self.name)
		print('DOB: ', self.dob)
		print('Colour: ', self.colour)
		print('Breed: ', self.breed)
		print('Class: ', self.myclass)



class cat():
	myclass = "cat"

	def __init__(self, name, dob, colour, breed):
		self.name = name
		self.dob = dob
		self.colour = colour
		self.breed = breed

	def printit(self):
		print('Name: ', self.name)
		print('DOB: ', self.dob)
		print('Colour: ', self.colour)
		print('Breed: ', self.breed)
		print('Class: ', self.myclass)

class bird():
	myclass = "bird"

	def __init__(self, name, dob, colour, breed):
		self.name = name
		self.dob = dob
		self.colour = colour
		self.breed = breed

	def printit(self):
		print('Name: ', self.name)
		print('DOB: ', self.dob)
		print('Colour: ', self.colour)
		print('Breed: ', self.breed)
		print('Class: ', self.myclass)
