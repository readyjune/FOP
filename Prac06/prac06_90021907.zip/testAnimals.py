from animals import Cat
from animals import Dog
from animals import Bird



garfield = Cat('Garfield', '1/1/1978', 'Orange', 'Tabby')

garfield.printit()

print(garfield)


goldretriever = Dog('Goldretriever', '2/2/1990', 'Gold', 'June')

goldretriever.printit()

print(goldretriever)


flamingo = Bird('Flamingo', '3/3/1999', 'Red', 'fli')

flamingo.printit()

print(flamingo)

