from animals import Cat
from animals import Dog
from animals import Bird



garfield = Cat('Garfield', '1/1/1978', 'Orange', 'Tabby')

garfield.printit()

print(garfield)



