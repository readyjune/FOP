#
# testing.py - test program for textfun.py
#
import textfun

testString = 'helloHELLO'

print(textfun.novowels(testString))
print(textfun.reverseupper(testString))
